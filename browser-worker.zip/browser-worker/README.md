# Browser Worker (Tareeka 2)

Ubuntu VPS par background service ki tarah chalne wala **Playwright (headless Chromium)** worker.
Tum JSON mein steps likhte ho (goto, fill, click, wait, extract...), worker unhe queue se ek-ek karke chalata hai.
**CAPTCHA / OTP / verification ke time wo ruk jaata hai**, tum phone se live screenshot par tap karte ho, OTP type
karte ho, "Resume" dabate ho, aur worker aage badh jaata hai.

## Ye kya hai aur kya nahi
- Hai: apni / client ki **apni sites aur apne accounts** ka kaam (form bharna, onboarding, data entry, checks, screenshots).
- Nahi (jaan-bujh ke): `undetected-chromedriver`/stealth, proxy rotation, CAPTCHA-solver. Ye sirf platform ko chhalne ke
  kaam aate hain. "Fully autonomous social-media account banana" bhi isi mein aata hai, isliye isme CAPTCHA/OTP **hamesha insaan** karta hai.
- Guardrails: sirf `allowed_domains` par kaam; allowlist se bahar redirect/click par task BLOCKED; har domain par
  tasks ke beech minimum gap aur 24-ghante ki limit (config se badal sakte ho).

## Structure
```
bw/config.py    config + allowlist           bw/spec.py      task validate + {{variables}}
bw/browser.py   Chromium lifecycle           bw/runner.py    steps, retries, fallback selectors, guard
bw/retry.py     transient errors par retry   bw/handoff.py   CAPTCHA/OTP: insaan ko control
bw/worker.py    queue loop (crash-safe)      bw/store.py     SQLite (secrets yahan kabhi nahi)
bw/api.py       HTTP API + /console UI       bw/main.py      entry point
deploy/         install.sh + systemd unit    tests/          34 end-to-end tests (asli Chromium)
```

## Local chalana (test ke liye)
```bash
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt && playwright install --with-deps chromium
python tests/test_all.py                        # saare 34 checks
export WORKER_API_KEY=$(openssl rand -hex 24)
python -m bw.main --config examples/config.example.json     # phir http://127.0.0.1:8080/console
```
(`tests/test_all.py` Google Colab mein bhi chal sakta hai: `!pip install playwright && !playwright install --with-deps chromium`.)

## Task format
```json
{ "name": "contact form", "variables": {"email": "me@example.com"},
  "secrets": {"password": "..."},
  "steps": [
    {"action": "goto", "url": "https://example.com/contact"},
    {"action": "fill", "selector": "#email", "fallbacks": ["input[name=email]"], "value": "{{email}}"},
    {"action": "fill", "selector": "#pw", "value": "{{password}}"},
    {"action": "human_pause", "reason": "CAPTCHA solve karo", "timeout_s": 600},
    {"action": "click", "selector": "button[type=submit]", "retries": 0},
    {"action": "expect_text", "selector": "body", "text": "Thank you"},
    {"action": "screenshot", "name": "done"} ] }
```
Actions: `goto fill click press select check wait_for wait_ms expect_text expect_url screenshot extract human_pause`.
Har step par optional: `fallbacks` (backup selectors), `retries` (0-5), `timeout_ms`. `fill` par `"slow": true` = dheere type.
`extract`: `save_as` zaroori, `attr` optional (`"value"` = input ki abhi ki value).
**Submit/pay jaise non-repeatable click par `"retries": 0` lagao.** Retry sirf timeout / network drop / HTTP 5xx-429 par hota hai.
`secrets` sirf memory mein rehte hain: DB, logs, API response mein kabhi nahi aate (task restart par chala jaata hai).

## API (header `X-API-Key`)
`POST /tasks` · `GET /tasks` · `GET /tasks/{id}` · `GET /tasks/{id}/screenshot` · `POST /tasks/{id}/command`
(`click x,y` / `type text` / `key` / `scroll dy` / `resume` / `cancel`) · `POST /tasks/{id}/cancel` · `GET /health` (bina key) · `GET /console` (UI)

## VPS par deploy (Ubuntu 22.04/24.04, root)
```bash
sudo bash deploy/install.sh example.com,app.example.com     # allowed domains
```
Ye: user `bw` banata, venv + Chromium install karta, config (`/etc/browser-worker/config.json`), random API key
(`/etc/browser-worker/env`), systemd service (auto-restart, memory limit), firewall (sirf SSH) set karta hai.
- Console kholna: `ssh -L 8080:127.0.0.1:8080 user@VPS_IP` phir `http://127.0.0.1:8080/console` (API key daalo).
  Phone se: Termux/ConnectBot SSH tunnel, ya Tailscale, ya HTTPS proxy:
  `worker.tumhari-site.com { reverse_proxy 127.0.0.1:8080 }` (Caddy, auto HTTPS).
- Logs: `journalctl -u browser-worker -f` aur `/opt/browser-worker/data/logs/worker.log` (rotating 5x5 MB).
- Restart / update: `sudo systemctl restart browser-worker`; naya code ke liye `install.sh` dobara chalao.
- VPS size: **2 GB RAM** theek hai (1 GB mein swap lagao). Cost aam taur par $5-10/mahina, provider ki site par dekh lo.
- Port 8080 ko internet par khula mat chhodo; API key ke bina kuch nahi hota, par console HTTPS ke peeche hi rakho.

## Safety / security
- Screenshots mein private cheezein ho sakti hain: `data/` permission 700, 7 din baad auto-delete.
- Typed text (OTP/password) log nahi hota, sirf lambai. Insaan allowlist se bahar navigate nahi kar sakta.
- Sirf apne/client ke apne accounts, ek-ek karke, site ke Terms ke andar. Bulk/fake accounts ke liye ise mat use karo.

## Jo test hua aur jo nahi
Hua (sandbox, asli Chromium): validation, secrets hygiene, fallback selector, retries (503 -> retry), allowlist block,
human handoff (API + phone-size console UI), cancel/timeout, limits, restart recovery, `python -m bw.main` start/stop.
Nahi hua: `install.sh` + systemd asli Ubuntu VPS par (yahan root/systemd nahi), asli phone, aur kisi bhi asli website par.
Pehle VPS par `tests/test_all.py` chalao, phir apni site par chhota task.

## Client ko kya promise karna
Asli kaam: "form/onboarding automation + CAPTCHA/OTP par insaan ki confirmation". Social platforms par "poori tarah
automatic account creation" promise mat karo: wo unke niyam ke khilaf hai aur account ban hote hain. Pehle chhota paid pilot lo,
VPS ka kharcha usi se nikalo, aur scope mein sites ki list likho.
