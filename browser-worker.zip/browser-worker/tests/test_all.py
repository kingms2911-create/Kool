"""End-to-end tests: asli Chromium + local test site. Chalao:  python tests/test_all.py"""
import json
import os
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from playwright.sync_api import sync_playwright  # noqa: E402

from bw import api  # noqa: E402
from bw.config import Config  # noqa: E402
from bw.logger import setup  # noqa: E402
from bw.store import Store  # noqa: E402
from bw.worker import Worker  # noqa: E402

FAILS = []
HITS = {"flaky": 0, "always503": 0}


def check(label, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + label + (f"   [{extra}]" if extra and not cond else ""))
    if not cond:
        FAILS.append(label)


# ---------------- test website ----------------
PAGES = {
    "/form.html": """<h1>Signup Test</h1><input id=email placeholder=email><input id=pw type=password>
<button id=go>Go</button><div id=ok style="display:none"></div>
<script>go.onclick=()=>setTimeout(()=>{ok.textContent='Welcome '+email.value;ok.style.display='block'},300)</script>""",
    "/fallback.html": "<h1>Fallback</h1><input name=email><button id=go>Go</button>",
    "/captcha.html": """<h1>Human check</h1><label><input type=checkbox id=human> I am human</label><br>
<input id=otp placeholder=otp><br><button id=sub>Submit</button><div id=done style="display:none"></div>
<script>sub.onclick=()=>{if(human.checked&&otp.value){done.textContent='OTP:'+otp.value;done.style.display='block'}}</script>""",
}


class Site(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        p = self.path.split("?")[0]
        if p == "/flaky":
            HITS["flaky"] += 1
            if HITS["flaky"] <= 2:
                return self._send(503, "busy")
            return self._send(200, "<h1 id=t>ok after retries</h1>")
        if p == "/always503":
            HITS["always503"] += 1
            return self._send(503, "down")
        if p == "/redirect":
            self.send_response(302)
            self.send_header("Location", f"http://127.0.0.2:{self.server.server_port}/form.html")
            self.end_headers()
            return
        if p in PAGES:
            return self._send(200, PAGES[p])
        self._send(404, "nope")

    def _send(self, code, body):
        b = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)


site = ThreadingHTTPServer(("0.0.0.0", 0), Site)
threading.Thread(target=site.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{site.server_port}"

# ---------------- worker + api ----------------
tmp = tempfile.mkdtemp()
cfg = Config(data_dir=tmp, allowed_domains=["127.0.0.1"], port=0, api_key="k" * 24,
             min_seconds_between_tasks_per_domain=0, max_tasks_per_day_per_domain=1000,
             default_timeout_ms=2500, nav_timeout_ms=8000, step_retries=2, backoff_base_s=0.1,
             human_default_timeout_s=40, task_max_seconds=90)
setup(tmp)
store = Store(os.path.join(tmp, "tasks.db"))
worker = Worker(cfg, store)
worker.start()
server = api.make_server(cfg, store, worker)
API = f"http://127.0.0.1:{server.server_port}"
threading.Thread(target=server.serve_forever, daemon=True).start()


def call(method, path, body=None, key=cfg.api_key):
    req = urllib.request.Request(API + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"X-API-Key": key, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read()
            return r.status, (raw if r.headers.get("Content-Type", "").startswith("image") else json.loads(raw or b"{}"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def submit(spec, secrets=None):
    body = dict(spec)
    if secrets:
        body["secrets"] = secrets
    return call("POST", "/tasks", body)


def wait(tid, targets=("done", "failed", "cancelled"), timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        s, t = call("GET", f"/tasks/{tid}")
        if t.get("status") in targets:
            return t
        time.sleep(0.4)
    return call("GET", f"/tasks/{tid}")[1]


def run_ok(spec, secrets=None, targets=("done", "failed", "cancelled")):
    s, d = submit(spec, secrets)
    assert s == 201, (s, d)
    return d["id"], wait(d["id"], targets)


log_text = lambda: open(os.path.join(tmp, "logs", "worker.log"), encoding="utf-8").read()  # noqa: E731

# 1) validation
print("--- validation ---")
bad = [
    ("URL allowlist se bahar", {"steps": [{"action": "goto", "url": "https://evil.example.org/"}]}),
    ("selector missing", {"steps": [{"action": "goto", "url": BASE + "/form.html"}, {"action": "click"}]}),
    ("undefined variable", {"steps": [{"action": "goto", "url": BASE + "/form.html"}, {"action": "fill", "selector": "#email", "value": "{{nope}}"}]}),
    ("first step goto nahi", {"steps": [{"action": "click", "selector": "#a"}]}),
    ("unknown action", {"steps": [{"action": "goto", "url": BASE + "/form.html"}, {"action": "hack"}]}),
]
for label, spec in bad:
    s, d = submit(spec)
    check(f"rejected: {label}", s == 400, f"{s} {d}")
s, d = submit({"steps": [{"action": "goto", "url": BASE + "/{{pw}}"}]}, {"pw": "x"})
check("rejected: secret URL mein", s == 400, f"{s} {d}")
check("auth: no key / wrong key -> 401", call("GET", "/tasks", key="")[0] == 401 and call("GET", "/tasks", key="x" * 24)[0] == 401)
check("health open + worker alive", call("GET", "/health", key="")[1].get("worker_alive") is True)

# 2) happy path + secrets hygiene
print("--- happy path ---")
SECRET = "S3cr3t-PW-9911"
tid, t = run_ok({"name": "happy", "variables": {"email": "me@x.com"}, "steps": [
    {"action": "goto", "url": BASE + "/form.html"},
    {"action": "fill", "selector": "#email", "value": "{{email}}"},
    {"action": "fill", "selector": "#pw", "value": "{{password}}"},
    {"action": "click", "selector": "#go", "retries": 0},
    {"action": "wait_for", "selector": "#ok"},
    {"action": "expect_text", "selector": "#ok", "text": "Welcome {{email}}"},
    {"action": "extract", "selector": "#ok", "save_as": "welcome"},
    {"action": "screenshot", "name": "final"}]}, {"password": SECRET})
check("happy: done + extracted text", t["status"] == "done" and t["result"]["extracted"].get("welcome") == "Welcome me@x.com", str(t))
check("happy: screenshot artifact + live.png", os.path.exists(os.path.join(tmp, "artifacts", tid, "final.png")) and os.path.exists(os.path.join(tmp, "artifacts", tid, "live.png")))
db_dump = open(os.path.join(tmp, "tasks.db"), "rb").read()
check("secret NOT in db or logs", SECRET.encode() not in db_dump and SECRET not in log_text())
check("API task view has no spec/secret", SECRET not in json.dumps(call("GET", f"/tasks/{tid}")[1]))

# 3) fallback selector
print("--- fallback / retries ---")
_, t = run_ok({"name": "fallback", "steps": [
    {"action": "goto", "url": BASE + "/fallback.html"},
    {"action": "fill", "selector": "#email", "timeout_ms": 800, "fallbacks": ["input[name=email]"], "value": "a@b.c"},
    {"action": "extract", "selector": "input[name=email]", "attr": "value", "save_as": "v"}]})
check("fallback selector used", t["status"] == "done" and t["result"]["extracted"]["v"] == "a@b.c", str(t))

# 4) transient retry
_, t = run_ok({"name": "flaky", "steps": [{"action": "goto", "url": BASE + "/flaky"},
                                          {"action": "extract", "selector": "#t", "save_as": "t"}]})
check("flaky 503,503,200 -> retried and done", t["status"] == "done" and HITS["flaky"] == 3 and t["result"]["extracted"]["t"] == "ok after retries", f"hits={HITS['flaky']} {t}")
_, t = run_ok({"name": "down", "steps": [{"action": "goto", "url": BASE + "/always503"}]})
check("always 503 -> 3 attempts then failed", t["status"] == "failed" and HITS["always503"] == 3 and "503" in t["error"], f"hits={HITS['always503']} {t}")
_, t2 = run_ok({"name": "after-failure", "steps": [{"action": "goto", "url": BASE + "/form.html"}]})
check("worker survives failure and runs next task", t2["status"] == "done")

# 5) non-transient failure not retried; page-level errors
_, t = run_ok({"name": "wrong text", "steps": [{"action": "goto", "url": BASE + "/form.html"},
                                               {"action": "expect_text", "selector": "h1", "text": "NOT THERE", "timeout_ms": 800}]})
check("expect_text mismatch -> failed (clear error)", t["status"] == "failed" and "text" in t["error"], str(t))
_, t = run_ok({"name": "404", "steps": [{"action": "goto", "url": BASE + "/missing"}]})
check("HTTP 404 -> failed without retries", t["status"] == "failed" and "404" in t["error"], str(t))

# 6) allowlist guard on redirect
print("--- allowlist ---")
_, t = run_ok({"name": "redirect", "steps": [{"action": "goto", "url": BASE + "/redirect"}]})
check("redirect to non-allowlisted host -> BLOCKED", t["status"] == "failed" and "BLOCKED" in t["error"], str(t))

# 7) human handoff through the API
print("--- human handoff (API) ---")


def centers():
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": cfg.viewport_w, "height": cfg.viewport_h})
        pg.goto(BASE + "/captcha.html")
        out = {}
        for k in ("human", "otp", "sub"):
            bb = pg.locator("#" + k).bounding_box()
            out[k] = (bb["x"] + bb["width"] / 2, bb["y"] + bb["height"] / 2)
        b.close()
        return out


C = centers()
CAPTCHA = {"name": "captcha", "steps": [
    {"action": "goto", "url": BASE + "/captcha.html"},
    {"action": "human_pause", "reason": "checkbox + OTP", "timeout_s": 40},
    {"action": "wait_for", "selector": "#done"},
    {"action": "extract", "selector": "#done", "save_as": "res"}]}
s, d = submit(CAPTCHA)
tid = d["id"]
t = wait(tid, ("waiting_human", "failed", "done"))
check("pauses with status waiting_human + reason", t["status"] == "waiting_human" and t["reason"] == "checkbox + OTP", str(t))
code, png = call("GET", f"/tasks/{tid}/screenshot")
check("live screenshot is a PNG", code == 200 and png[:4] == b"\x89PNG")
check("bad command rejected (400)", call("POST", f"/tasks/{tid}/command", {"cmd": "format_disk"})[0] == 400)
check("click with null/NaN coords rejected (400), task keeps waiting",
      call("POST", f"/tasks/{tid}/command", {"cmd": "click", "x": None, "y": 5})[0] == 400
      and call("POST", f"/tasks/{tid}/command", {"cmd": "key", "key": "F12"})[0] == 400
      and call("GET", f"/tasks/{tid}")[1]["status"] == "waiting_human")
call("POST", f"/tasks/{tid}/command", {"cmd": "click", "x": 99999, "y": 99999})       # viewport ke bahar: ignore
call("POST", f"/tasks/{tid}/command", {"cmd": "click", "x": C["human"][0], "y": C["human"][1]})
call("POST", f"/tasks/{tid}/command", {"cmd": "click", "x": C["otp"][0], "y": C["otp"][1]})
call("POST", f"/tasks/{tid}/command", {"cmd": "type", "text": "246810"})
call("POST", f"/tasks/{tid}/command", {"cmd": "click", "x": C["sub"][0], "y": C["sub"][1]})
call("POST", f"/tasks/{tid}/command", {"cmd": "resume"})
t = wait(tid)
check("human solved -> task continues and finishes", t["status"] == "done" and t["result"]["extracted"].get("res") == "OTP:246810", str(t))
check("typed OTP never logged", "246810" not in log_text() and "human type: 6 akshar" in log_text())
check("command on finished task -> 409", call("POST", f"/tasks/{tid}/command", {"cmd": "resume"})[0] == 409)

# 8) cancel while waiting, and human timeout
s, d = submit(CAPTCHA)
wait(d["id"], ("waiting_human",))
check("cancel while waiting_human", call("POST", f"/tasks/{d['id']}/cancel", {})[0] == 200 and wait(d["id"])["status"] == "cancelled")
_, t = run_ok({"name": "timeout", "steps": [{"action": "goto", "url": BASE + "/captcha.html"},
                                            {"action": "human_pause", "timeout_s": 2}]})
check("nobody answers -> failed with clear reason", t["status"] == "failed" and "insaan" in t["error"], str(t))

# 9) caps, throttle, restart recovery
print("--- limits / recovery ---")
simple = {"name": "simple", "steps": [{"action": "goto", "url": BASE + "/form.html"}]}
saved = cfg.max_tasks_per_day_per_domain
cfg.max_tasks_per_day_per_domain = store.count_recent("127.0.0.1")
check("daily cap per domain -> 429", submit(simple)[0] == 429)
cfg.max_tasks_per_day_per_domain = saved
cfg.min_seconds_between_tasks_per_domain = 3
a = submit(simple)[1]["id"]; wait(a)
b = submit(simple)[1]["id"]; tb = wait(b)
ta = call("GET", f"/tasks/{a}")[1]
check("min delay between tasks on same domain", tb["started"] - ta["finished"] >= 2.5, f"gap={tb['started'] - ta['finished']:.1f}s")
cfg.min_seconds_between_tasks_per_domain = 0
fake1 = store.add("orphan-running", "127.0.0.1", simple); store.update(fake1, status="running")
fake2 = store.add("orphan-waiting", "127.0.0.1", simple); store.update(fake2, status="waiting_human")
n = store.mark_interrupted()
check("restart recovery marks unfinished tasks failed", n >= 2 and store.get(fake1)["status"] == "failed" and "restart" in store.get(fake1)["error"])

# 10) console UI on a phone-sized screen (tap screenshot, type OTP, resume)
print("--- console UI (phone viewport) ---")
s, d = submit(CAPTCHA)
tid = d["id"]
wait(tid, ("waiting_human",))
with sync_playwright() as p:
    br = p.chromium.launch()
    ctx = br.new_context(viewport={"width": 390, "height": 844}, has_touch=True)
    pg = ctx.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto(API + "/console")
    pg.evaluate("k => localStorage.setItem('bw_key', k)", cfg.api_key)
    pg.reload()
    pg.wait_for_selector(".t")
    pg.locator(".t", has_text="captcha").first.click()
    pg.wait_for_selector("#shot:not([hidden])")
    pg.wait_for_timeout(500)
    check("console shows waiting_human + controls", pg.inner_text("#dst") == "waiting_human" and not pg.locator("#ctl").is_hidden())

    def tap(name):
        pg.wait_for_function("document.getElementById('shot').naturalWidth > 0")
        box = pg.locator("#shot").bounding_box()
        nat = pg.evaluate("[document.getElementById('shot').naturalWidth, document.getElementById('shot').naturalHeight]")
        x, y = C[name]
        pg.mouse.click(box["x"] + x * box["width"] / nat[0], box["y"] + y * box["height"] / nat[1])
        pg.wait_for_timeout(900)

    tap("human"); tap("otp")
    pg.fill("#txt", "135790"); pg.click("#type"); pg.wait_for_timeout(700)
    tap("sub")
    pg.click("#resume")
    t = wait(tid)
    check("console: tap + type + resume -> done with OTP", t["status"] == "done" and t["result"]["extracted"].get("res") == "OTP:135790", str(t))
    check("console: no JS errors", not errs, str(errs))
    br.close()

worker.stop(); server.shutdown(); site.shutdown()
print("\nRESULT:", "ALL PASSED" if not FAILS else f"{len(FAILS)} FAILED: {FAILS}")
sys.exit(1 if FAILS else 0)
