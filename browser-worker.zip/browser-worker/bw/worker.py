"""Background worker: queue se ek-ek task uthata hai, crash hone par bhi loop zinda rehta hai."""
import json
import os
import shutil
import threading
import time

from .browser import BrowserManager
from .handoff import Cancelled, Handoff, HumanTimeout
from .logger import log
from .retry import BrowserDied
from .runner import Blocked, Runner, StepError


class Worker(threading.Thread):
    def __init__(self, cfg, store):
        super().__init__(daemon=True, name="bw-worker")
        self.cfg, self.store = cfg, store
        self.bm = BrowserManager(cfg)
        self.secrets, self.handoffs, self.cancelled = {}, {}, set()   # secrets sirf memory mein
        self.stop_evt = threading.Event()
        self.current = None
        self._cleaned = 0.0

    # ----- API ke liye -----
    def art_dir(self, tid):
        d = os.path.join(self.cfg.data_dir, "artifacts", tid)
        os.makedirs(d, mode=0o700, exist_ok=True)
        return d

    def send_command(self, tid, cmd):
        h = self.handoffs.get(tid)
        if not h:
            return False
        h.q.put(cmd)
        return True

    def cancel(self, tid):
        t = self.store.get(tid)
        if not t:
            return False
        if t["status"] == "queued":
            self.store.update(tid, status="cancelled", finished=time.time())
            self.secrets.pop(tid, None)
            return True
        if t["status"] in ("running", "waiting_human"):
            self.cancelled.add(tid)
            h = self.handoffs.get(tid)
            if h:
                h.q.put({"cmd": "cancel"})
            return True
        return False

    def stop(self):
        self.stop_evt.set()

    # ----- loop -----
    def throttle_wait(self, domain):
        last = self.store.last_finished(domain)
        return max(0.0, last + self.cfg.min_seconds_between_tasks_per_domain - time.time()) if last else 0.0

    def cleanup(self):
        if time.time() - self._cleaned < 3600:
            return
        self._cleaned = time.time()
        root, limit = os.path.join(self.cfg.data_dir, "artifacts"), time.time() - self.cfg.artifact_retention_days * 86400
        for name in os.listdir(root) if os.path.isdir(root) else []:
            p = os.path.join(root, name)
            if os.path.isdir(p) and os.path.getmtime(p) < limit:
                shutil.rmtree(p, ignore_errors=True)
        self.store.purge(30)

    def run(self):
        log.info("worker loop shuru")
        while not self.stop_evt.is_set():
            try:
                self.cleanup()
                t = self.store.next_queued()
                if not t:
                    self.stop_evt.wait(1)
                    continue
                wait = self.throttle_wait(t["domain"])
                if wait > 0:
                    self.stop_evt.wait(min(wait, 2))
                    continue
                self.run_task(t)
            except Exception:
                log.exception("worker loop error (loop chalta rahega)")
                self.stop_evt.wait(2)
        self.bm.stop()
        log.info("worker band")

    def run_task(self, t):
        tid, spec = t["id"], json.loads(t["spec"])
        secrets = self.secrets.pop(tid, {})
        art = self.art_dir(tid)
        handoff = Handoff(tid, art, (self.cfg.viewport_w, self.cfg.viewport_h))
        self.handoffs[tid], self.current = handoff, tid
        started, paused = time.time(), {"total": 0.0}

        def update(**kw):                       # insaan ke intezaar ka time task-limit mein nahi ginte
            if kw.get("status") == "waiting_human":
                paused["since"] = time.time()
            elif kw.get("status") == "running" and "since" in paused:
                paused["total"] += time.time() - paused.pop("since")
            self.store.update(tid, **kw)

        def scrub(msg):
            for s in secrets.values():
                if len(str(s)) >= 3:
                    msg = msg.replace(str(s), "***")
            return msg

        def finish(status, error=""):
            self.store.update(tid, status=status, error=scrub(error)[:300], finished=time.time(), step="")
            log.info("task=%s %s %s", tid, status.upper(), scrub(error)[:200])

        self.store.update(tid, status="running", started=started, step="")
        log.info("task=%s shuru name=%r domain=%s", tid, t["name"], t["domain"])
        ctx = page = None
        failed = True
        try:
            self.bm.start()
            ctx = self.bm.new_context()
            page = ctx.new_page()
            page.on("dialog", lambda d: d.dismiss())
            runner = Runner(self.cfg, page, tid, spec, secrets, handoff, art, update,
                            lambda: tid in self.cancelled,
                            lambda: started + self.cfg.task_max_seconds + paused["total"])
            result = runner.run()
            self.store.update(tid, status="done", result=result, finished=time.time(), step="")
            log.info("task=%s DONE", tid)
            failed = False
        except Cancelled:
            finish("cancelled", "user ne cancel kiya")
        except HumanTimeout as e:
            finish("failed", str(e))
        except Blocked as e:
            finish("failed", f"BLOCKED: {e}")
        except StepError as e:
            finish("failed", str(e))
        except BrowserDied as e:
            finish("failed", f"browser band ho gaya: {e}")
            self.bm.browser = None               # agle task par fresh browser
        except Exception as e:
            log.exception("task=%s fail", tid)
            finish("failed", f"{type(e).__name__}: {str(e).splitlines()[0] if str(e) else ''}")
        finally:
            if failed and page is not None:
                try:
                    handoff.shot(page)           # fail ke waqt ka screenshot (live.png)
                except Exception:
                    pass
            try:
                if ctx:
                    ctx.close()
            except Exception:
                pass
            self.handoffs.pop(tid, None)
            self.cancelled.discard(tid)
            self.current = None
