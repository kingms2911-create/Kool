"""Insaan ko control dena (CAPTCHA / OTP / verification).

Worker pause hota hai, live screenshot save karta hai, aur insaan (phone se) API ke zariye
tap / type / key / resume bhejta hai. Typed text kabhi log nahi hota (sirf lambai).
"""
import os
import queue
import time

from .logger import log

KEYS = {"Enter", "Tab", "Backspace", "Escape", "ArrowDown", "ArrowUp", "Space", "Delete"}


class Cancelled(Exception):
    pass


class HumanTimeout(Exception):
    pass


class Handoff:
    def __init__(self, task_id, art_dir, viewport):
        self.task_id, self.art_dir, self.viewport = task_id, art_dir, viewport
        self.q = queue.Queue()
        self.live = os.path.join(art_dir, "live.png")

    def shot(self, page):
        """Atomic write: padhne wala kabhi aadhi file nahi dekhta."""
        tmp = self.live + ".tmp.png"
        page.screenshot(path=tmp)
        os.replace(tmp, self.live)

    def _apply(self, page, cmd):
        c = cmd.get("cmd")
        if c == "click":
            x, y = float(cmd["x"]), float(cmd["y"])
            if 0 <= x <= self.viewport[0] and 0 <= y <= self.viewport[1]:
                page.mouse.click(x, y)
        elif c == "type":
            text = str(cmd.get("text", ""))[:200]
            log.info("task=%s human type: %d akshar", self.task_id, len(text))   # text log nahi hota
            page.keyboard.type(text, delay=40)
        elif c == "key" and cmd.get("key") in KEYS:
            page.keyboard.press(cmd["key"])
        elif c == "scroll":
            page.mouse.wheel(0, max(-1500, min(1500, float(cmd.get("dy", 0)))))
        try:
            page.wait_for_load_state("domcontentloaded", timeout=2000)
        except Exception:
            pass

    def wait(self, page, reason, timeout_s, guard, set_status):
        """resume aane tak ruko. cancel -> Cancelled, time khatam -> HumanTimeout."""
        set_status("waiting_human", reason)
        log.info("task=%s insaan ka intezaar: %s (max %ss)", self.task_id, reason, timeout_s)
        self.shot(page)
        deadline, last = time.time() + timeout_s, time.time()
        try:
            while time.time() < deadline:
                try:
                    cmd = self.q.get(timeout=0.5)
                except queue.Empty:
                    cmd = None
                if cmd:
                    c = cmd.get("cmd")
                    if c == "resume":
                        guard()
                        log.info("task=%s insaan ne resume kiya", self.task_id)
                        return
                    if c == "cancel":
                        raise Cancelled()
                    try:
                        self._apply(page, cmd)
                    except Exception as e:       # kharab command ignore, task chalta rahe
                        log.warning("task=%s command ignore hua (%s)", self.task_id, type(e).__name__)
                    guard()                      # insaan allowlist se bahar nahi ja sakta
                    self.shot(page)
                    last = time.time()
                elif time.time() - last > 3:
                    self.shot(page)
                    last = time.time()
            raise HumanTimeout(f"{timeout_s}s mein insaan ne jawab nahi diya")
        finally:
            set_status("running", "")
