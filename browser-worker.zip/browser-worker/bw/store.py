"""SQLite task store. Secrets yahan kabhi save nahi hote (sirf memory mein)."""
import json
import sqlite3
import threading
import time
import uuid

COLS = {"status", "step", "reason", "error", "result", "started", "finished"}
FINAL = ("done", "failed", "cancelled")


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.db.execute("""CREATE TABLE IF NOT EXISTS tasks(
                id TEXT PRIMARY KEY, name TEXT, domain TEXT, status TEXT, spec TEXT,
                created REAL, started REAL, finished REAL,
                error TEXT DEFAULT '', result TEXT DEFAULT '{}', reason TEXT DEFAULT '', step TEXT DEFAULT '')""")
            self.db.commit()

    def _row(self, r):
        if not r:
            return None
        d = dict(r)
        d["result"] = json.loads(d["result"] or "{}")
        return d

    def add(self, name, domain, spec):
        tid = uuid.uuid4().hex[:12]
        with self.lock:
            self.db.execute("INSERT INTO tasks(id,name,domain,status,spec,created) VALUES(?,?,?,?,?,?)",
                            (tid, name, domain, "queued", json.dumps(spec), time.time()))
            self.db.commit()
        return tid

    def get(self, tid):
        with self.lock:
            return self._row(self.db.execute("SELECT * FROM tasks WHERE id=?", (tid,)).fetchone())

    def list(self, limit=50):
        with self.lock:
            rows = self.db.execute("SELECT * FROM tasks ORDER BY created DESC LIMIT ?", (limit,)).fetchall()
        return [self._row(r) for r in rows]

    def update(self, tid, **kw):
        kw = {k: v for k, v in kw.items() if k in COLS}
        if "result" in kw:
            kw["result"] = json.dumps(kw["result"])
        if not kw:
            return
        with self.lock:
            self.db.execute(f"UPDATE tasks SET {','.join(k + '=?' for k in kw)} WHERE id=?", (*kw.values(), tid))
            self.db.commit()

    def next_queued(self):
        with self.lock:
            return self._row(self.db.execute(
                "SELECT * FROM tasks WHERE status='queued' ORDER BY created LIMIT 1").fetchone())

    def mark_interrupted(self):
        with self.lock:
            cur = self.db.execute(
                "UPDATE tasks SET status='failed', error='server restart se interrupted', finished=? "
                "WHERE status NOT IN ('done','failed','cancelled')", (time.time(),))
            self.db.commit()
            return cur.rowcount

    def count_recent(self, domain, seconds=86400):
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM tasks WHERE domain=? AND created>? AND status!='cancelled'",
                                   (domain, time.time() - seconds)).fetchone()[0]

    def last_finished(self, domain):
        with self.lock:
            return self.db.execute("SELECT MAX(finished) FROM tasks WHERE domain=?", (domain,)).fetchone()[0]

    def purge(self, days=30):
        with self.lock:
            self.db.execute("DELETE FROM tasks WHERE created<? AND status IN ('done','failed','cancelled')",
                            (time.time() - days * 86400,))
            self.db.commit()
