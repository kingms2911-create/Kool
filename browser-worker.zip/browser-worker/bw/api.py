"""Chhota HTTP API (stdlib, extra dependency nahi). Default 127.0.0.1 par; HTTPS proxy ya SSH tunnel se use karo."""
import hmac
import json
import os
import re
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .handoff import KEYS
from .logger import log
from .spec import IDENT, SpecError, validate

ID = re.compile(r"^[a-f0-9]{12}$")
CONSOLE = os.path.join(os.path.dirname(__file__), "static", "console.html")
CMDS = {"click", "type", "key", "scroll", "shot", "resume", "cancel"}


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and v == v and abs(v) < 1e6


def valid_cmd(b):
    c = b.get("cmd")
    if c == "click":
        return _num(b.get("x")) and _num(b.get("y"))
    if c == "type":
        return isinstance(b.get("text"), str) and 0 < len(b["text"]) <= 200
    if c == "key":
        return b.get("key") in KEYS
    if c == "scroll":
        return _num(b.get("dy"))
    return True


def public(t):
    keep = ("id", "name", "domain", "status", "step", "reason", "error", "result", "created", "started", "finished")
    return {k: t[k] for k in keep}


def make_server(cfg, store, worker):
    class H(BaseHTTPRequestHandler):
        server_version = "bw"

        def log_message(self, *a):
            pass

        def _send(self, code, body, ctype="application/json"):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass                                    # client ne beech mein connection band kar diya

        def _json(self, code, obj):
            self._send(code, json.dumps(obj).encode())

        def _auth(self):
            ok = hmac.compare_digest(self.headers.get("X-API-Key", "").encode(), cfg.api_key.encode())
            if not ok:
                time.sleep(0.5)
                self._json(401, {"error": "Invalid API key"})
            return ok

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > 262144:
                raise ValueError("body bahut bada hai")
            return json.loads(self.rfile.read(n) or b"{}")

        def _tid(self, parts):
            tid = parts[1] if len(parts) > 1 else ""
            t = store.get(tid) if ID.match(tid) else None
            if not t:
                self._json(404, {"error": "task nahi mila"})
            return t

        def do_GET(self):
            parts = [p for p in self.path.split("?")[0].split("/") if p]
            if not parts or parts == ["console"]:
                with open(CONSOLE, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if parts == ["health"]:
                return self._json(200, {"ok": True, "worker_alive": worker.is_alive(), "running": worker.current})
            if not self._auth():
                return
            if parts == ["tasks"]:
                return self._json(200, [public(t) for t in store.list(50)])
            if parts[0] == "tasks" and len(parts) in (2, 3):
                t = self._tid(parts)
                if not t:
                    return
                if len(parts) == 2:
                    return self._json(200, public(t))
                if parts[2] == "screenshot":
                    p = os.path.join(worker.art_dir(t["id"]), "live.png")
                    if not os.path.exists(p):
                        return self._json(404, {"error": "abhi screenshot nahi hai"})
                    with open(p, "rb") as f:
                        return self._send(200, f.read(), "image/png")
            self._json(404, {"error": "route nahi mila"})

        def do_POST(self):
            parts = [p for p in self.path.split("?")[0].split("/") if p]
            if not self._auth():
                return
            try:
                body = self._body()
            except (ValueError, json.JSONDecodeError) as e:
                return self._json(400, {"error": f"JSON galat: {e}"})
            if parts == ["tasks"]:
                return self._submit(body)
            if parts[:1] == ["tasks"] and len(parts) == 3:
                t = self._tid(parts)
                if not t:
                    return
                if parts[2] == "cancel":
                    if t["status"] not in ("queued", "running", "waiting_human"):
                        return self._json(409, {"error": "task khatam ho chuka hai"})
                    worker.cancel(t["id"])
                    return self._json(200, {"ok": True})
                if parts[2] == "command":
                    c = body.get("cmd")
                    if c not in CMDS:
                        return self._json(400, {"error": f"cmd allowed: {', '.join(sorted(CMDS))}"})
                    if not valid_cmd(body):
                        return self._json(400, {"error": "command ke fields galat hain (x/y number, text max 200, key allowed list mein)"})
                    if t["status"] != "waiting_human" or not worker.send_command(t["id"], body):
                        return self._json(409, {"error": "task abhi insaan ka intezaar nahi kar raha"})
                    return self._json(200, {"ok": True})
            self._json(404, {"error": "route nahi mila"})

        def _submit(self, body):
            secrets = body.pop("secrets", None) or {}
            if not isinstance(secrets, dict) or not all(isinstance(v, str) and len(v) <= 200 for v in secrets.values()):
                return self._json(400, {"error": "secrets: {naam: text} (max 200 akshar)"})
            if not all(IDENT.match(str(k)) for k in secrets):
                return self._json(400, {"error": "secret ka naam galat"})
            try:
                domain = validate(body, cfg, secrets.keys())
            except SpecError as e:
                return self._json(400, {"error": str(e)})
            if store.count_recent(domain) >= cfg.max_tasks_per_day_per_domain:
                return self._json(429, {"error": f"{domain} par 24 ghante ki limit ({cfg.max_tasks_per_day_per_domain} tasks) poori"})
            name = str(body.get("name") or "task")[:80]
            tid = store.add(name, domain, body)
            if secrets:
                worker.secrets[tid] = secrets
            log.info("task=%s queued name=%r domain=%s steps=%d", tid, name, domain, len(body["steps"]))
            self._json(201, {"id": tid, "domain": domain})

    return ThreadingHTTPServer((cfg.host, cfg.port), H)
