"""Logging: rotating file + stdout (systemd journal). Secrets log mein nahi jaate."""
import logging
import logging.handlers
import os
import re

SENSITIVE = re.compile(r"pass|secret|token|otp|pin|key|cookie|auth", re.I)
log = logging.getLogger("bw")


def mask(d):
    return {k: ("***" if SENSITIVE.search(str(k)) else v) for k, v in (d or {}).items()}


def setup(data_dir, level=logging.INFO):
    os.makedirs(os.path.join(data_dir, "logs"), exist_ok=True)
    log.setLevel(level)
    log.handlers.clear()
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fh = logging.handlers.RotatingFileHandler(os.path.join(data_dir, "logs", "worker.log"),
                                              maxBytes=5_000_000, backupCount=5, encoding="utf-8")
    sh = logging.StreamHandler()
    for h in (fh, sh):
        h.setFormatter(fmt)
        log.addHandler(h)
    return log
