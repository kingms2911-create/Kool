"""Entry point:  python -m bw.main --config /etc/browser-worker/config.json"""
import argparse
import os
import signal
import threading

from . import api, config
from .logger import log, setup
from .store import Store
from .worker import Worker


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", help="config JSON ka path")
    cfg = config.load(ap.parse_args().config)
    os.makedirs(os.path.join(cfg.data_dir, "artifacts"), mode=0o700, exist_ok=True)
    os.chmod(cfg.data_dir, 0o700)                       # screenshots mein private cheezein ho sakti hain
    setup(cfg.data_dir)
    store = Store(os.path.join(cfg.data_dir, "tasks.db"))
    n = store.mark_interrupted()
    if n:
        log.warning("%d adhoore task 'interrupted' mark hue (server restart)", n)
    worker = Worker(cfg, store)
    worker.start()
    server = api.make_server(cfg, store, worker)

    def stop(*_):
        log.info("band karne ka signal mila")
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    log.info("API chal raha hai http://%s:%s  (allowed: %s)", cfg.host, cfg.port, ", ".join(cfg.allowed_domains))
    try:
        server.serve_forever()
    finally:
        worker.stop()
        worker.join(30)
        log.info("bye")


if __name__ == "__main__":
    main()
