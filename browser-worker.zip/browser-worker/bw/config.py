"""Config: JSON file + env overrides. Allowlist aur API key zaroori hain."""
import json
import os
from dataclasses import dataclass, field, fields


@dataclass
class Config:
    data_dir: str = "data"
    allowed_domains: list = field(default_factory=list)
    host: str = "127.0.0.1"          # bahar expose mat karo; SSH tunnel ya HTTPS proxy use karo
    port: int = 8080
    headless: bool = True
    sandbox: bool = False            # True = Chromium sandbox (Ubuntu 24.04 par AppArmor setting chahiye)
    viewport_w: int = 1280
    viewport_h: int = 800
    locale: str = "en-IN"
    timezone: str = "Asia/Kolkata"
    default_timeout_ms: int = 15000
    nav_timeout_ms: int = 30000
    step_retries: int = 2            # fail hone par extra koshish (sirf transient errors par)
    backoff_base_s: float = 1.5
    min_seconds_between_tasks_per_domain: int = 30
    max_tasks_per_day_per_domain: int = 20
    restart_browser_after_tasks: int = 25
    task_max_seconds: int = 900      # insaan ke intezaar ka time isme nahi gina jata
    human_default_timeout_s: int = 600
    artifact_retention_days: int = 7
    api_key: str = ""

    def host_allowed(self, host):
        host = (host or "").lower().strip(".")
        return bool(host) and any(host == d or host.endswith("." + d) for d in self.allowed_domains)


def load(path=None):
    data = {}
    if path:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    known = {f.name for f in fields(Config)} - {"api_key"}
    cfg = Config(**{k: v for k, v in data.items() if k in known})
    cfg.api_key = os.getenv("WORKER_API_KEY", "")
    if os.getenv("WORKER_DATA_DIR"):
        cfg.data_dir = os.environ["WORKER_DATA_DIR"]
    if os.getenv("WORKER_PORT"):
        cfg.port = int(os.environ["WORKER_PORT"])
    cfg.allowed_domains = [d.lower().strip(".") for d in cfg.allowed_domains if d.strip()]
    if not cfg.allowed_domains:
        raise SystemExit("config: allowed_domains khali hai. Sirf wahi sites likho jinpar kaam karna hai.")
    if len(cfg.api_key) < 16:
        raise SystemExit("WORKER_API_KEY set karo (kam se kam 16 akshar).")
    return cfg
