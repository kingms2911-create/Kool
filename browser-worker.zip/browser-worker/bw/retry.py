"""Retry sirf transient errors par: timeout, network drop, HTTP 5xx/429."""
import random
import time

from playwright.sync_api import Error as PWError
from playwright.sync_api import TimeoutError as PWTimeout

NET_MARKERS = ("net::ERR_", "ECONNRESET", "ERR_CONNECTION", "ERR_TIMED_OUT", "ERR_NAME_NOT_RESOLVED")


class TransientHTTP(Exception):
    pass


class BrowserDied(Exception):
    pass


def is_transient(e):
    if isinstance(e, (PWTimeout, TransientHTTP)):
        return True
    return isinstance(e, PWError) and any(m in str(e) for m in NET_MARKERS)


def with_retries(fn, attempts, base, log, what):
    """attempts = kul koshish (1 = retry nahi). Exponential backoff + thoda jitter."""
    for i in range(max(1, attempts)):
        try:
            return fn()
        except Exception as e:
            if isinstance(e, PWError) and "has been closed" in str(e):
                raise BrowserDied(str(e)[:120]) from e
            if i == attempts - 1 or not is_transient(e):
                raise
            delay = base * (2 ** i) + random.uniform(0, 0.3)
            log.warning("%s: transient error (%s), %.1fs baad retry %d/%d", what, str(e).splitlines()[0][:100],
                        delay, i + 1, attempts - 1)
            time.sleep(delay)
