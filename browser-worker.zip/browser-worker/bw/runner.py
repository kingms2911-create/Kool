"""Ek task ke steps chalata hai: retries, fallback selectors, allowlist guard, insaan-handoff."""
import os
import re
import time
from urllib.parse import urlparse

from playwright.sync_api import TimeoutError as PWTimeout
from playwright.sync_api import expect

from .handoff import Cancelled
from .logger import log
from .retry import TransientHTTP, with_retries
from .spec import render

NO_RETRY = {"human_pause", "screenshot", "wait_ms"}


class Blocked(Exception):
    """Page allowlist se bahar chala gaya."""


class StepError(Exception):
    """Step logic fail (non-transient): retry nahi hota."""


class Runner:
    def __init__(self, cfg, page, task_id, spec, secrets, handoff, art_dir, update, is_cancelled, deadline):
        self.cfg, self.page, self.id, self.spec = cfg, page, task_id, spec
        self.vars = {**(spec.get("variables") or {}), **secrets}
        self.handoff, self.art_dir, self.update = handoff, art_dir, update
        self.is_cancelled, self.deadline = is_cancelled, deadline
        self.extracted = {}

    # ----- helpers -----
    def r(self, text):
        return render(text, self.vars)

    def guard(self):
        url = self.page.url
        if url.startswith("about:"):
            return
        host = urlparse(url).hostname
        if not self.cfg.host_allowed(host):
            raise Blocked(f"page allowlist se bahar gaya: {host}")

    def locate(self, step, state="visible"):
        timeout = step.get("timeout_ms", self.cfg.default_timeout_ms)
        cands = [step["selector"]] + list(step.get("fallbacks") or [])
        first_err = None
        for n, sel in enumerate(cands):
            loc = self.page.locator(self.r(sel)).first
            try:
                loc.wait_for(state=state, timeout=timeout if n == 0 else min(timeout, 3000))
                if n:
                    log.info("task=%s fallback selector #%d use hua", self.id, n)
                return loc
            except PWTimeout as e:
                first_err = first_err or e
        raise first_err

    def after_action(self):
        try:
            self.page.wait_for_load_state("domcontentloaded", timeout=3000)
        except PWTimeout:
            pass
        self.guard()

    def set_status(self, status, reason=""):
        self.update(status=status, reason=reason)

    # ----- ek step -----
    def exec(self, step):
        a, p = step["action"], self.page
        timeout = step.get("timeout_ms", self.cfg.default_timeout_ms)
        if a == "goto":
            resp = p.goto(self.r(step["url"]), wait_until="domcontentloaded")
            st = resp.status if resp else 0
            if st == 429 or st >= 500:
                raise TransientHTTP(f"HTTP {st}")
            if st >= 400:
                raise StepError(f"HTTP {st}")
            self.guard()
        elif a == "fill":
            loc, value = self.locate(step), self.r(step["value"])
            if step.get("slow"):
                loc.click()
                loc.fill("")
                loc.press_sequentially(value, delay=40)
            else:
                loc.fill(value)
        elif a == "click":
            self.locate(step).click()
            self.after_action()
        elif a == "press":
            self.locate(step).press(step["key"])
            self.after_action()
        elif a == "select":
            self.locate(step).select_option(self.r(step["value"]))
        elif a == "check":
            self.locate(step).check()
        elif a == "wait_for":
            self.locate(step, step.get("state", "visible"))
        elif a == "wait_ms":
            time.sleep(min(step["ms"], 10000) / 1000)
        elif a == "expect_text":
            try:
                expect(self.locate(step)).to_contain_text(self.r(step["text"]), timeout=timeout)
            except AssertionError as e:
                raise StepError("expected text nahi mila") from e
        elif a == "expect_url":
            needle = self.r(step["contains"])
            try:
                p.wait_for_url(lambda u: needle in u, timeout=timeout)
            except PWTimeout as e:
                raise StepError(f"URL mein '{needle}' nahi aaya (abhi: {p.url})") from e
        elif a == "screenshot":
            name = re.sub(r"[^a-z0-9_-]", "", str(step.get("name", "shot")).lower())[:40] or "shot"
            p.screenshot(path=os.path.join(self.art_dir, name + ".png"))
        elif a == "extract":
            loc = self.locate(step)
            if step.get("attr") == "value":          # input ki abhi ki (bhari hui) value
                val = loc.input_value()
            elif step.get("attr"):
                val = loc.get_attribute(step["attr"])
            else:
                val = loc.inner_text()
            self.extracted[step["save_as"]] = (val or "").strip()[:1000]
        elif a == "human_pause":
            self.handoff.wait(p, step.get("reason", "Insaan ki madad chahiye"),
                              step.get("timeout_s", self.cfg.human_default_timeout_s), self.guard, self.set_status)

    # ----- poora task -----
    def run(self):
        steps = self.spec["steps"]
        for i, step in enumerate(steps, 1):
            if self.is_cancelled():
                raise Cancelled()
            if time.time() > self.deadline():
                raise StepError("task ka time-limit khatam")
            a = step["action"]
            self.update(step=f"{i}/{len(steps)} {a}")
            attempts = 1 if a in NO_RETRY else int(step.get("retries", self.cfg.step_retries)) + 1
            log.info("task=%s step %d/%d %s", self.id, i, len(steps), a)
            with_retries(lambda: self.exec(step), attempts, self.cfg.backoff_base_s, log, f"task={self.id} step {i} {a}")
        self.handoff.shot(self.page)
        return {"extracted": self.extracted, "final_url": self.page.url}
