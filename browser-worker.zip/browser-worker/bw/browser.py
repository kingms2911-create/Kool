"""Chromium ka lifecycle: ek browser, har task ke liye naya isolated context. Real browser, koi stealth nahi."""
from playwright.sync_api import sync_playwright

from .logger import log


class BrowserManager:
    def __init__(self, cfg):
        self.cfg, self.pw, self.browser, self.count = cfg, None, None, 0

    def _launch(self):
        self.browser = self.pw.chromium.launch(
            headless=self.cfg.headless, chromium_sandbox=self.cfg.sandbox,
            args=["--disable-dev-shm-usage"])        # chhote /dev/shm wale VPS ke liye
        self.count = 0
        log.info("browser start hua (%s)", self.browser.version)

    def start(self):
        if self.pw is None:
            self.pw = sync_playwright().start()
        if self.browser is None or not self.browser.is_connected():
            self._launch()

    def healthy(self):
        return self.browser is not None and self.browser.is_connected()

    def new_context(self):
        if not self.healthy() or self.count >= self.cfg.restart_browser_after_tasks:
            self.restart()
        self.count += 1
        ctx = self.browser.new_context(
            viewport={"width": self.cfg.viewport_w, "height": self.cfg.viewport_h},
            locale=self.cfg.locale, timezone_id=self.cfg.timezone, accept_downloads=False)
        ctx.set_default_timeout(self.cfg.default_timeout_ms)
        ctx.set_default_navigation_timeout(self.cfg.nav_timeout_ms)
        return ctx

    def restart(self):
        log.info("browser restart (memory saaf / crash recovery)")
        try:
            if self.browser:
                self.browser.close()
        except Exception:
            pass
        self.browser = None
        self.start()

    def stop(self):
        try:
            if self.browser:
                self.browser.close()
            if self.pw:
                self.pw.stop()
        except Exception:
            pass
        self.browser = self.pw = None
