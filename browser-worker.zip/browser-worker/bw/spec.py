"""Task spec: validate + {{variable}} templating. Galat spec run hone se pehle hi reject."""
import re
from urllib.parse import urlparse

ACTIONS = {"goto", "fill", "click", "press", "select", "check", "wait_for", "wait_ms",
           "expect_text", "expect_url", "screenshot", "extract", "human_pause"}
NEEDS_SELECTOR = {"fill", "click", "press", "select", "check", "wait_for", "expect_text", "extract"}
VAR = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")
IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,40}$")


class SpecError(ValueError):
    pass


def render(text, variables):
    def sub(m):
        if m.group(1) not in variables:
            raise SpecError(f"variable '{m.group(1)}' defined nahi hai")
        return str(variables[m.group(1)])
    return VAR.sub(sub, str(text))


def _strings(step):
    for v in step.values():
        if isinstance(v, str):
            yield v
        elif isinstance(v, list):
            yield from (x for x in v if isinstance(x, str))


def validate(spec, cfg, secret_names=()):
    """Sahi ho to first-goto ka domain return karta hai, warna SpecError."""
    if not isinstance(spec, dict):
        raise SpecError("spec JSON object hona chahiye")
    steps = spec.get("steps")
    if not isinstance(steps, list) or not 1 <= len(steps) <= 60:
        raise SpecError("steps: 1 se 60 steps ki list chahiye")
    variables = spec.get("variables") or {}
    if not isinstance(variables, dict) or not all(IDENT.match(str(k)) for k in variables):
        raise SpecError("variables: naam sirf akshar/number/_ ")
    for n in secret_names:
        if not IDENT.match(str(n)) or n in variables:
            raise SpecError(f"secret ka naam galat ya variables se takra raha hai: {n}")
    defined = set(variables) | set(secret_names)
    plain = {k: v for k, v in variables.items()}
    errors, domain = [], None
    for i, s in enumerate(steps, 1):
        if not isinstance(s, dict) or s.get("action") not in ACTIONS:
            errors.append(f"step {i}: action galat (allowed: {', '.join(sorted(ACTIONS))})")
            continue
        a = s["action"]
        if i == 1 and a != "goto":
            errors.append("step 1 'goto' hona chahiye")
        if a in NEEDS_SELECTOR and not isinstance(s.get("selector"), str):
            errors.append(f"step {i} ({a}): selector chahiye")
        if a == "goto":
            try:
                url = render(s.get("url", ""), plain)
            except SpecError as e:
                errors.append(f"step {i}: URL mein secret/undefined variable nahi chalta ({e})")
                continue
            u = urlparse(url)
            if u.scheme not in ("http", "https") or not cfg.host_allowed(u.hostname):
                errors.append(f"step {i}: URL allowlist mein nahi ({u.hostname})")
            elif domain is None:
                domain = u.hostname.lower()
        if a in ("fill", "select") and "value" not in s:
            errors.append(f"step {i} ({a}): value chahiye")
        if a == "press" and not s.get("key"):
            errors.append(f"step {i}: key chahiye")
        if a == "expect_text" and not s.get("text"):
            errors.append(f"step {i}: text chahiye")
        if a == "expect_url" and not s.get("contains"):
            errors.append(f"step {i}: contains chahiye")
        if a == "extract" and not IDENT.match(str(s.get("save_as", ""))):
            errors.append(f"step {i}: save_as (naam) chahiye")
        if a == "wait_ms" and not (isinstance(s.get("ms"), int) and 0 < s["ms"] <= 10000):
            errors.append(f"step {i}: ms 1 se 10000 ke beech")
        if "retries" in s and not (isinstance(s["retries"], int) and 0 <= s["retries"] <= 5):
            errors.append(f"step {i}: retries 0 se 5")
        if "timeout_ms" in s and not (isinstance(s["timeout_ms"], int) and 500 <= s["timeout_ms"] <= 120000):
            errors.append(f"step {i}: timeout_ms 500 se 120000")
        for t in _strings(s):
            for name in VAR.findall(t):
                if name not in defined:
                    errors.append(f"step {i}: variable '{name}' defined nahi hai")
    if domain is None and not errors:
        errors.append("kam se kam ek goto chahiye")
    if errors:
        raise SpecError("; ".join(errors[:6]))
    return domain
