"""Browser Worker: Playwright par chalne wala, insaan-ke-saath (CAPTCHA/OTP) browser automation."""
