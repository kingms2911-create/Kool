#!/usr/bin/env bash
# Ubuntu 22.04 / 24.04 VPS par install:   sudo bash deploy/install.sh example.com,app.example.com
# Argument = wo domains jinpar worker ko kaam karne ki ijazat hai (allowlist).
set -euo pipefail

DOMAINS="${1:-}"
APP=/opt/browser-worker
CONF=/etc/browser-worker
SRC="$(cd "$(dirname "$0")/.." && pwd)"

[ "$(id -u)" = 0 ] || { echo "root se chalao: sudo bash deploy/install.sh domain1.com,domain2.com"; exit 1; }
[ -n "$DOMAINS" ]  || { echo "allowed domains do: sudo bash deploy/install.sh example.com"; exit 1; }

echo "==> packages"
apt-get update -y
apt-get install -y python3 python3-venv python3-pip rsync curl ca-certificates ufw openssl

echo "==> user + files"
id -u bw >/dev/null 2>&1 || useradd --system --create-home --home-dir "$APP" --shell /usr/sbin/nologin bw
mkdir -p "$APP/data" "$CONF"
rsync -a --delete --exclude 'data' --exclude 'venv' --exclude '.pw' --exclude 'tests' --exclude '__pycache__' "$SRC"/ "$APP"/
chown -R bw:bw "$APP"
chmod 700 "$APP/data"

echo "==> python venv + playwright"
sudo -u bw python3 -m venv "$APP/venv"
sudo -u bw "$APP/venv/bin/pip" install --upgrade pip
sudo -u bw "$APP/venv/bin/pip" install -r "$APP/requirements.txt"
export PLAYWRIGHT_BROWSERS_PATH="$APP/.pw"
"$APP/venv/bin/playwright" install-deps chromium            # system libraries (root chahiye)
sudo -u bw env PLAYWRIGHT_BROWSERS_PATH="$APP/.pw" "$APP/venv/bin/playwright" install chromium

echo "==> config"
python3 - "$DOMAINS" "$CONF/config.json" <<'PY'
import json, sys
domains = [d.strip() for d in sys.argv[1].split(",") if d.strip()]
json.dump({"allowed_domains": domains, "host": "127.0.0.1", "port": 8080,
           "data_dir": "/opt/browser-worker/data"}, open(sys.argv[2], "w"), indent=2)
PY
if [ ! -f "$CONF/env" ]; then
  KEY="$(openssl rand -hex 24)"
  printf 'WORKER_API_KEY=%s\nPLAYWRIGHT_BROWSERS_PATH=%s/.pw\n' "$KEY" "$APP" > "$CONF/env"
  chmod 600 "$CONF/env"
  echo "NAYI API KEY (kahin save kar lo): $KEY"
else
  echo "(purani API key rakhi: $CONF/env)"
fi

echo "==> service"
cp "$APP/deploy/browser-worker.service" /etc/systemd/system/browser-worker.service
systemctl daemon-reload
systemctl enable --now browser-worker

echo "==> firewall (sirf SSH khula; API 127.0.0.1 par hi hai)"
ufw allow OpenSSH >/dev/null || true
ufw --force enable >/dev/null || true

sleep 3
systemctl --no-pager --lines=5 status browser-worker || true
curl -s http://127.0.0.1:8080/health && echo
echo "Ho gaya. Console: SSH tunnel se kholo ->  ssh -L 8080:127.0.0.1:8080 USER@VPS_IP  phir http://127.0.0.1:8080/console"
